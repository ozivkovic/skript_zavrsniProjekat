'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Grupa extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({ Kurs,Predavac,Pohadjanje}) {
        // define association here
        this.belongsTo(Kurs, {foreignKey: 'kursId', as: 'kurs'});
        this.belongsTo(Predavac, {foreignKey: 'predavacId', as: 'predavac'});

        this.hasMany(Pohadjanje, { foreignKey: 'grupaId', as: 'pohadjanje', onDelete: 'cascade', hooks: true });
        
      }
  }
  Grupa.init({
    oznaka: {
        type: DataTypes.STRING,
        allowNull: false
      },
  }, {
    sequelize,
    modelName: 'Grupa',
  });
  return Grupa;
};