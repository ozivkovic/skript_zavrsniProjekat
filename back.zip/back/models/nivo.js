'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Nivo extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({ Kurs }) {
      // define association here
      this.hasMany(Kurs, { foreignKey: 'nivoId', as: 'kurs', onDelete: 'cascade', hooks: true });
    }
  }
  Nivo.init({
    oznaka: {
      type: DataTypes.STRING,
      allowNull: false
    },
    opis: {
        type: DataTypes.STRING,
        allowNull: true
      }
  }, {
    sequelize,
    modelName: 'Nivo',
  });
  return Nivo;
};