'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Znanje_Jezika extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({ Jezik,Predavac }) {
        // define association here
        this.belongsTo(Jezik, {foreignKey: 'jezikId', as: 'jezik'});
        this.belongsTo(Predavac, {foreignKey: 'predavacId', as: 'predavac'});
        
      }
  }
  Znanje_Jezika.init({
    /*jezikId: {
        type: DataTypes.STRING,
        allowNull: false
      },
      predavacId: {
        type: DataTypes.STRING,
        allowNull: false
      },*/
    
  }, {
    sequelize,
    modelName: 'Znanje_Jezika',
  });
  return Znanje_Jezika;
};