'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Polaznik extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Pohadjanje}) {
      // define association here

      this.hasMany(Pohadjanje, { foreignKey: 'polaznikId', as: 'pohadjanje', onDelete: 'cascade', hooks: true });

    }
  }
  Polaznik.init({
    ime: {
      type: DataTypes.STRING,
      allowNull: false
    },
    prezime: {
      type: DataTypes.STRING,
      allowNull: false
    },
    godiste: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Polaznik',
  });
  return Polaznik;
};