'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Predavac extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({ Znanje_Jezika,Grupa }) {
      // define association here
      this.hasMany(Znanje_Jezika, { foreignKey: 'predavacId', as: 'znanje_jezika', onDelete: 'cascade', hooks: true });
      this.hasMany(Grupa, { foreignKey: 'predavacId', as: 'grupa', onDelete: 'cascade', hooks: true });

    }
  }
  Predavac.init({
    ime: {
      type: DataTypes.STRING,
      allowNull: false
    },
    prezime: {
      type: DataTypes.STRING,
      allowNull: false
    },
    radni_staz: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Predavac',
  });
  return Predavac;
};