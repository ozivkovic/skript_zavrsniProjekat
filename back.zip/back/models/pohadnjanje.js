'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Pohadjanje extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({ Grupa,Polaznik }) {
        // define association here
        this.belongsTo(Grupa, {foreignKey: 'grupaId', as: 'grupa'});
        this.belongsTo(Polaznik, {foreignKey: 'polaznikId', as: 'polaznik'});
        
      }
  }
  Pohadjanje.init({
    /*jezikId: {
        type: DataTypes.STRING,
        allowNull: false
      },
      predavacId: {
        type: DataTypes.STRING,
        allowNull: false
      },*/
    
  }, {
    sequelize,
    modelName: 'Pohadjanje',
  });
  return Pohadjanje;
};