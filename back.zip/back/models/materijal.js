'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Materijal extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate({Kurs}) {
      // define association here
      this.belongsTo(Kurs, {foreignKey: 'kursId', as: 'kurs'});
    }
  }
  Materijal.init({
    naziv: {
      type: DataTypes.STRING,
      allowNull: false
    },
    autor: {
        type: DataTypes.STRING,
        allowNull: false
      },
  }, {
    sequelize,
    modelName: 'Materijal',
  });
  return Materijal;
};