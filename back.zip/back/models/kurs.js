'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Kurs extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
     static associate({ Tip_Kursa,Nivo,Jezik,Materijal,Grupa}) {
        // define association here
       this.belongsTo(Tip_Kursa, {foreignKey: 'tipKursaId', as: 'tip_kursa'});
       this.belongsTo(Jezik, {foreignKey: 'jezikId', as: 'jezik'});
       this.belongsTo(Nivo, {foreignKey: 'nivoId', as: 'nivo'});

       this.hasMany(Materijal, { foreignKey: 'kursId', as: 'materijal', onDelete: 'cascade', hooks: true });
       this.hasMany(Grupa, { foreignKey: 'kursId', as: 'grupa', onDelete: 'cascade', hooks: true });

      }
  }
  Kurs.init({
    naziv: {
        type: DataTypes.STRING,
        allowNull: false
      }
  }, {
    sequelize,
    modelName: 'Kurs',
  });
  return Kurs;
};