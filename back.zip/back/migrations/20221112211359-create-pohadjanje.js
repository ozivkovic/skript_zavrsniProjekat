'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Pohadjanjes', {
      id: {
        allowNull: true,
        type: Sequelize.INTEGER
      },
      grupaId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      polaznikId: {
        allowNull: false,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Pohadjanjes');
  }
};