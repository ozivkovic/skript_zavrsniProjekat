function init() {

    const cookies = document.cookie.split('=');
    const token = cookies[cookies.length - 1];
    

    fetch('http://127.0.0.1:8002/admin/users', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
        .then( res => res.json() )
        .then( data => {
            const lst = document.getElementById('usrLst');
            var ca = token;
            var base64Url = ca.split('.')[1];
            var decodedValue = JSON.parse(window.atob(base64Url));
            console.log(decodedValue.userId);
            data.forEach( el => {
                if(el.id==decodedValue.userId){
                lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                }
            });
        });
        
    fetch('http://127.0.0.1:8002/admin/grupa', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
            .then( res =>res.json())
            .then( data => {
                const lst = document.getElementById('usrLst2');
                data.forEach( el => {
                    lst.innerHTML += `<li>Oznaka: ${el.oznaka}, Kurs id: ${el.kursId}, Predavac id: ${el.predavacId}</li>`;
                });
        });

        
    
    

    document.getElementById('grupaBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            oznaka: document.getElementById('oznaka').value,
            kursId: document.getElementById('kursId').value,
            predavacId: document.getElementById('predavacId').value,
        };

        document.getElementById('oznaka').value='';
        document.getElementById('kursId').value='';
        document.getElementById('predavacId').value='';
        
    

        fetch('http://127.0.0.1:8002/admin/grupa', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res => res.json() )
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('grupaLst').innerHTML += `<li>Dodata grupa: Oznaka: ${el.oznaka}, Kurs id: ${el.kursId}, Predavac id: ${el.predavacId}</li>`;
                }
            });
    });



    document.getElementById('obrisiBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('idGrupe').value,
        };
       
        

        fetch('http://127.0.0.1:8002/admin/grupa/'+data.id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('grupaLst').innerHTML += `<li>Obrisana grupa: Oznaka: ${el.oznaka}, Kurs id: ${el.kursId}, Predavac id: ${el.predavacId}</li>`;
                }
            });
    });

    document.getElementById('izmeniBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            oznaka: document.getElementById('oznakaUpdate').value,
            kursId:document.getElementById('kursIdUpdate').value,
            predavacId:document.getElementById('predavacIdUpdate').value
        };
        
       
        const b=document.getElementById('idGrupeUpdate').value;

        fetch('http://127.0.0.1:8002/admin/grupa/'+b, {
            
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('grupaLst').innerHTML += `<li>Izmenjena grupa sa id:${b} , novi atributi:  ${el.oznaka}, Kurs id: ${el.kursId}, Predavac id: ${el.predavacId}</li>`;
                    
                }
            });
    });




    document.getElementById('logout').addEventListener('click', e => {
        document.cookie = `token=;SameSite=Lax`;
        window.location.href = 'login.html';
    });
}