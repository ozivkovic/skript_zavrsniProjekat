function init() {

    const cookies = document.cookie.split('=');
    const token = cookies[cookies.length - 1];

   
    fetch('http://127.0.0.1:8002/admin/users', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
        .then( res => res.json() )
        .then( data => {
            const lst = document.getElementById('usrLst');
            var ca = token;
            var base64Url = ca.split('.')[1];
            var decodedValue = JSON.parse(window.atob(base64Url));
            console.log(decodedValue.userId);
            data.forEach( el => {
                if(el.id==decodedValue.userId){
                lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                }
            });
        });  

        fetch('http://127.0.0.1:8002/admin/users/login', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
            .then( res => res.json() )
            .then( data => {
                const lst = document.getElementById('usrLst2');
    
                data.forEach( el => {
                    lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                });
            });  

            

    document.getElementById('dodajBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            name: document.getElementById('name').value,
            password: document.getElementById('password').value,
            admin: document.getElementById('admin').value,
            email: document.getElementById('email').value
        };

       
        fetch('http://127.0.0.1:8002/admin/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res => res.json() )
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    const lst = document.getElementById('usrLst');
                    var ca = token;
                    var base64Url = ca.split('.')[1];
                    var decodedValue = JSON.parse(window.atob(base64Url));

                    fetch('http://127.0.0.1:8002/admin/users/'+decodedValue.userId, {
                        method: 'GET',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    })
                        .then( par => par.json() )
                        .then( data => {
                           if(data.admin==1){
                            document.getElementById('usersLst').innerHTML += `<li>Dodat user ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                           }
                           
                        });  
            
                }
            });
    });
    document.getElementById('obrisiBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('idUsera').value,
        };
        

        fetch('http://127.0.0.1:8002/admin/users/'+data.id, {
            
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    const lst = document.getElementById('usrLst');
                    var ca = token;
                    var base64Url = ca.split('.')[1];
                    var decodedValue = JSON.parse(window.atob(base64Url));

                    fetch('http://127.0.0.1:8002/admin/users/'+decodedValue.userId, {
                        method: 'GET',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    })
                        .then( par => par.json() )
                        .then( data => {
                           if(data.admin==1){
                            document.getElementById('usersLst').innerHTML += `<li>Izbrisan user: ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                        }
                           
                        });  
                }
            });
    });



    document.getElementById('izmeniBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            name: document.getElementById('nameUpdate').value,
            password: document.getElementById('passwordUpdate').value,
            admin: document.getElementById('adminUpdate').value,
            email:document.getElementById('emailUpdate').value
        };
        
        const b=document.getElementById('idUseraUpdate').value;

        fetch('http://127.0.0.1:8002/admin/users/'+b, {
            
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    const lst = document.getElementById('usrLst');
                    var ca = token;
                    var base64Url = ca.split('.')[1];
                    var decodedValue = JSON.parse(window.atob(base64Url));

                    fetch('http://127.0.0.1:8002/admin/users/'+decodedValue.userId, {
                        method: 'GET',
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    })
                        .then( par => par.json() )
                        .then( data => {
                           if(data.admin==1){
                            document.getElementById('usersLst').innerHTML += `<li>Izmenjen user sa id:${b} , novi atributi: Name: ${el.name}, E-mail: ${el.email},Password:${el.password}</li>`;                        }
                           
                        });  
                    
                }
            });
    });




    



    document.getElementById('logout').addEventListener('click', e => {
        document.cookie = `token=;SameSite=Lax`;
        window.location.href = 'login.html';
    });
}