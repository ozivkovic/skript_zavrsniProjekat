function init() {

    const cookies = document.cookie.split('=');
    const token = cookies[cookies.length - 1];

    fetch('http://127.0.0.1:8002/admin/users', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
        .then( res => res.json() )
        .then( data => {
            const lst = document.getElementById('usrLst');
            var ca = token;
            var base64Url = ca.split('.')[1];
            var decodedValue = JSON.parse(window.atob(base64Url));
            console.log(decodedValue.userId);
            data.forEach( el => {
                if(el.id==decodedValue.userId){
                lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                }
            });
        });
        
    fetch('http://127.0.0.1:8002/admin/materijal', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
            .then( res =>res.json())
            .then( data => {
                const lst = document.getElementById('usrLst2');
                data.forEach( el => {
                    lst.innerHTML += `<li>Naziv: ${el.naziv}, Autor: ${el.autor}, Kurs id: ${el.kursId}</li>`;
                });
        });
    
    

    document.getElementById('materijalBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            naziv: document.getElementById('naziv').value,
            autor: document.getElementById('autor').value,
            kursId: document.getElementById('kursId').value
        };

        document.getElementById('naziv').value='';
        document.getElementById('autor').value='';
        document.getElementById('kursId').value='';
    
    

        fetch('http://127.0.0.1:8002/admin/materijal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res => res.json() )
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('materijalLst').innerHTML += `<li>Dodat materijal: Naziv: ${el.naziv}, Autor: ${el.autor}, Kurs id: ${el.kursId}</li>`;
                }
            });
    });



    document.getElementById('obrisiBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('idMaterijala').value,
        };
        

        fetch('http://127.0.0.1:8002/admin/materijal/'+data.id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('materijalLst').innerHTML += `<li>Obrisan materijal: Naziv: ${el.naziv}, Autor: ${el.autor}, Kurs id: ${el.kursId}</li>`;
                }
            });
    });


    document.getElementById('izmeniBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            naziv: document.getElementById('nazivUpdate').value,
            autor:document.getElementById('autorUpdate').value,
            kursId:document.getElementById('kursIdUpdate').value
        };
       
        const b=document.getElementById('idMaterijalaUpdate').value;

        fetch('http://127.0.0.1:8002/admin/materijal/'+b, {
            
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('materijalLst').innerHTML += `<li>Izmenjen materijal sa id:${b} , novi atributi: Naziv: ${el.naziv}, Autor: ${el.autor}, Kurs id: ${el.kursId}</li>`;
                }
            });
    });




    document.getElementById('logout').addEventListener('click', e => {
        document.cookie = `token=;SameSite=Lax`;
        window.location.href = 'login.html';
    });
}