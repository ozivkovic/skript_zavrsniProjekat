function init() {

    const cookies = document.cookie.split('=');
    const token = cookies[cookies.length - 1];

   
    fetch('http://127.0.0.1:8002/admin/users', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
        .then( res => res.json() )
        .then( data => {
            const lst = document.getElementById('usrLst');
            var ca = token;
            var base64Url = ca.split('.')[1];
            var decodedValue = JSON.parse(window.atob(base64Url));
            console.log(decodedValue.userId);
            data.forEach( el => {
                if(el.id==decodedValue.userId){
                lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                }
            });
        });
        
    fetch('http://127.0.0.1:8002/admin/polaznik', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
            .then( res =>res.json())
            .then( data => {
                const lst = document.getElementById('usrLst2');
                data.forEach( el => {
                    lst.innerHTML += `<li>Ime: ${el.ime}, Prezime: ${el.prezime}</li>`;
                });
        });
    
    

    document.getElementById('polaznikBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            ime: document.getElementById('name').value,
            prezime: document.getElementById('prezime').value,
            godiste: document.getElementById('godiste').value
        };

        document.getElementById('name').value='';
        document.getElementById('prezime').value='';
        document.getElementById('godiste').value='';

        fetch('http://127.0.0.1:8002/admin/polaznik', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res => res.json() )
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('polaznikLst').innerHTML += `<li>Dodat polaznik Ime: ${el.ime}, Prezime: ${el.prezime}</li>`;
                }
            });
    });
    document.getElementById('obrisiBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('idPolaznika').value,
        };
        document.getElementById('idPolaznika').value='';
        

        fetch('http://127.0.0.1:8002/admin/polaznik/'+data.id, {
            
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('polaznikLst').innerHTML += `<li>Izbrisan polaznik: ${el.ime}, Prezime: ${el.prezime}</li>`;
                }
            });
    });



    document.getElementById('izmeniBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            ime: document.getElementById('nameUpdate').value,
            prezime: document.getElementById('prezimeUpdate').value,
            godiste: document.getElementById('godisteUpdate').value
        };
        document.getElementById('nameUpdate').value='';
        document.getElementById('prezimeUpdate').value='';
        document.getElementById('godisteUpdate').value='';
        const b=document.getElementById('idPolaznikaUpdate').value;

        fetch('http://127.0.0.1:8002/admin/polaznik/'+b, {
            
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('polaznikLst').innerHTML += `<li>Izmenjen polaznik sa id:${b} , novi atributi: Ime: ${el.ime}, Prezime: ${el.prezime}</li>`;
                    document.getElementById('idPolaznikaUpdate').value='';
                }
            });
    });

    document.getElementById('logout').addEventListener('click', e => {
        document.cookie = `token=;SameSite=Lax`;
        window.location.href = 'login.html';
    });
}