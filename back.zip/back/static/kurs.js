function init() {

    const cookies = document.cookie.split('=');
    const token = cookies[cookies.length - 1];

    fetch('http://127.0.0.1:8002/admin/users', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
        .then( res => res.json() )
        .then( data => {
            const lst = document.getElementById('usrLst');
            var ca = token;
            var base64Url = ca.split('.')[1];
            var decodedValue = JSON.parse(window.atob(base64Url));
            console.log(decodedValue.userId);
            data.forEach( el => {
                if(el.id==decodedValue.userId){
                lst.innerHTML += `<li>ID: ${el.id}, Name: ${el.name}, E-mail: ${el.email}</li>`;
                }
            });
        });
        
    fetch('http://127.0.0.1:8002/admin/kurs', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    })
            .then( res =>res.json())
            .then( data => {
                const lst = document.getElementById('usrLst2');
                data.forEach( el => {
                    lst.innerHTML += `<li>Naziv: ${el.naziv}, TipKursa id: ${el.tipKursaId}, Jezik id: ${el.jezikId}, Nivo id: ${el.nivoId}</li>`;
                });
        });
    
    

    document.getElementById('kursBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            naziv: document.getElementById('naziv').value,
            tipKursaId: document.getElementById('tipKursaId').value,
            jezikId: document.getElementById('jezikId').value,
            nivoId: document.getElementById('nivoId').value
        };

        document.getElementById('naziv').value='';
        document.getElementById('tipKursaId').value='';
        document.getElementById('jezikId').value='';
        document.getElementById('nivoId').value='';
    

        fetch('http://127.0.0.1:8002/admin/kurs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res => res.json() )
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('kursLst').innerHTML += `<li>Dodat kurs:Naziv: ${el.naziv}, TipKursa id: ${el.tipKursaId}, Jezik id: ${el.jezikId}, Nivo id: ${el.nivoId}</li>`;
                }
            });
    });



    document.getElementById('obrisiBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            id: document.getElementById('idKursa').value,
        };
        

        fetch('http://127.0.0.1:8002/admin/kurs/'+data.id, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('kursLst').innerHTML += `<li>Obrisan kurs: Naziv: ${el.naziv}, TipKursa id: ${el.tipKursaId}, Jezik id: ${el.jezikId}, Nivo id: ${el.nivoId}</li>`;
                }
            });
    });

    document.getElementById('izmeniBtn').addEventListener('click', e => {
        e.preventDefault();

        const data = {
            naziv: document.getElementById('nazivUpdate').value,
            tipKursaId:document.getElementById('tipKursaIdUpdate').value,
            jezikId:document.getElementById('jezikIdUpdate').value,
            nivoId:document.getElementById('nivoIdUpdate').value
        };
       
        const b=document.getElementById('idKursaUpdate').value;

        fetch('http://127.0.0.1:8002/admin/kurs/'+b, {
            
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(data)
        })
            .then( res =>res.json())
            .then( el => {
                if (el.msg) {
                    alert(el.msg);
                } else {
                    document.getElementById('kursLst').innerHTML += `<li>Izmenjen kurs sa id:${b} , novi atributi:  Naziv: ${el.naziv}, TipKursa id: ${el.tipKursaId}, Jezik id: ${el.jezikId}, Nivo id: ${el.nivoId}</li>`;
                }
            });
    });


    document.getElementById('logout').addEventListener('click', e => {
        document.cookie = `token=;SameSite=Lax`;
        window.location.href = 'login.html';
    });
}