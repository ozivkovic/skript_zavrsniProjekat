const express = require('express');
const { sequelize, Users,Kurs } = require('../models');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/kurs', async (req, res) => {
    try{
    const sviKursevi = await Kurs.findAll();
    return res.json(sviKursevi);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/kurs/:id', async (req, res) => {
    try {
        const kurs = await Kurs.findOne({ where: { id: req.params.id } });
        return res.json(kurs);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/kurs/:naziv/name', async (req, res) => {
    try {
        const kurs = await Kurs.findOne({ where: { naziv: req.params.naziv } });
        return res.json(kurs);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/kurs', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required(),
            tipKursaId:Joi.number().min(1).max(1000).required(),
            jezikId:Joi.number().min(1).max(1000).required(),
            nivoId:Joi.number().min(1).max(1000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviKurs = await Kurs.create(req.body);
        res.send(noviKurs);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/kurs/:id', async(req, res) => {
    try{
        const kurs=await Kurs.findOne({where:{id:req.body.id}});
        kurs.destroy();
        res.send(kurs);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/kurs/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required(),
            tipKursaId:Joi.number().min(1).max(1000).required(),
            jezikId:Joi.number().min(1).max(1000).required(),
            nivoId:Joi.number().min(1).max(1000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const kurs2= await Kurs.findByPk(req.params.id);
        kurs2.naziv = req.body.naziv;
        kurs2.tipKursaId=req.body.tipKursaId;
        kurs2.jezikId=req.body.jezikId;
        kurs2.nivoId=req.body.nivoId;
        kurs2.save();
        res.send(kurs2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;