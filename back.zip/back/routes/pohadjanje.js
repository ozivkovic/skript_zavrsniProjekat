const express = require('express');
const { sequelize, Users,Pohadjanje } = require('../models');
const jwt = require('jsonwebtoken');

require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

function authToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
  
    if (token == null) return res.status(401).json({ msg: err });
  
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
        if (err) return res.status(403).json({ msg: err });
    
        req.user = user;
        
        next();
    });
}

route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/pohadjanje', async (req, res) => {
    try{
    const svaPohadjanja = await Pohadjanje.findAll();
    return res.json(svaPohadjanja);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/pohadjanje', async (req, res) => {
    try{
        let novoPohadjanje = await Pohadjanje.create(req.body);
        res.send(novoPohadjanje);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/pohadjanje/:grupaId/details/:polaznikId', async(req, res) => {
    try{
        const pohadjanje=await Pohadjanje.findOne({
            where: {
                grupaId: req.body.grupaId,
                polaznikId: req.body.polaznikId
              }
        });
        pohadjanje.destroy();
        res.send(pohadjanje);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put('/pohadjanje/:grupaId/details/:polaznikId', async(req, res) => {
    try{
        const pohadjanje2 = await await Pohadjanje.findOne({
            where: {
                grupaId: req.body.grupaId,
                polaznikId: req.body.polaznikId
              }
        });
        
        pohadjanje2.grupaId = req.body.grupaIdNew;
        pohadjanje2.polaznikId = req.body.polaznikIdNew;
        pohadjanje2.save();
        res.send(pohadjanje2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;