const express = require('express');
const { sequelize, Users,Grupa } = require('../models');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/grupa', async (req, res) => {
    try{
    const sveGrupe = await Grupa.findAll();
    return res.json(sveGrupe);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/grupa/:id', async (req, res) => {
    try {

        const grupa = await Grupa.findOne({ where: { id: req.params.id } });
        return res.json(grupa);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});


route.post('/grupa', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            oznaka: Joi.string().min(1).max(10).required(),
            kursId:Joi.number().min(1).max(1000).required(),
            predavacId:Joi.number().min(1).max(1000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let novaGrupa = await Grupa.create(req.body);
        res.send(novaGrupa);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/grupa/:id', async(req, res) => {
    try{
        const grupa = await Grupa.findOne({ where: { id: req.params.id } });
        grupa.destroy();
        res.send(grupa);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/grupa/:id", async(req, res) => {
    try{
        
        const shema = Joi.object().keys({
            oznaka: Joi.string().min(1).max(10).required(),
            kursId:Joi.number().min(1).max(1000).required(),
            predavacId:Joi.number().min(1).max(1000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
    
    const grupa2 = await Grupa.findByPk(req.params.id);
    grupa2.oznaka = req.body.oznaka;
    grupa2.kursId = req.body.kursId;
    grupa2.predavacId = req.body.predavacId;
    
    try {
        const savedGrupa = await grupa2.save();
        res.send(savedGrupa);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska1", data: err });
    }
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska2", data: err });
    }
});

module.exports = route;