const express = require('express');
const { sequelize, Users,Nivo } = require('../models');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const Joi = require('joi');

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/nivo', async (req, res) => {
    try{
    const sviNivoi = await Nivo.findAll();
    return res.json(sviNivoi);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/nivo', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            oznaka: Joi.string().min(1).max(10).required(),
            opis:Joi.string().min(1).max(100).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviNivo = await Nivo.create(req.body);
        res.send(noviNivo);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/nivo/:id', async(req, res) => {
    try{
        const nivo=await Nivo.findOne({where:{id:req.body.id}});
        nivo.destroy();
        res.send(nivo);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/nivo/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            oznaka: Joi.string().min(1).max(10).required(),
            opis:Joi.string().min(1).max(100).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const nivo2 = await Nivo.findByPk(req.params.id);
        nivo2.oznaka = req.body.oznaka;
        nivo2.opis=req.body.opis;
        nivo2.save();
        res.send(nivo2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;