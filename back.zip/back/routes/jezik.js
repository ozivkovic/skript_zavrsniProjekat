const express = require('express');
const { sequelize, Users,Jezik } = require('../models');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/jezik', async (req, res) => {
    try{
    const sviJezici = await Jezik.findAll();
    return res.json(sviJezici);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/jezik', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviJezik = await Jezik.create(req.body);
        res.send(noviJezik);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/jezik/:id', async(req, res) => {
    try{
        const jezik=await Jezik.findOne({where:{id:req.body.id}});
        jezik.destroy();
        res.send(jezik);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/jezik/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const jezik2 = await Jezik.findByPk(req.params.id);
        jezik2.naziv = req.body.naziv;
        jezik2.save();
        res.send(jezik2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;