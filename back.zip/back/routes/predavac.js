const express = require('express');
const { sequelize, Users,Predavac } = require('../models');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/predavac', async (req, res) => {
    try{
    const sviPredavaci = await Predavac.findAll();
    return res.json(sviPredavaci);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/predavac/:id', async (req, res) => {
    try {
        const predavac = await Predavac.findOne({ where: { id: req.params.id } });
        return res.json(predavac);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/predavac/:ime/name', async (req, res) => {
    try {
        const predavac = await Predavac.findOne({ where: { ime: req.params.ime} });
        return res.json(predavac);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/predavac', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            ime: Joi.string().min(1).max(10).required(),
            prezime:Joi.string().min(1).max(10).required(),
            radni_staz:Joi.number().min(1).max(3000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviPredavac = await Predavac.create(req.body);
        res.send(noviPredavac);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/predavac/:id', async(req, res) => {
    try{
        const predavac=await Predavac.findOne({where:{id:req.body.id}});
        predavac.destroy();
        res.send(predavac);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/predavac/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            ime: Joi.string().min(1).max(10).required(),
            prezime:Joi.string().min(1).max(10).required(),
            radni_staz:Joi.number().min(1).max(3000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const predavac2 = await Predavac.findByPk(req.params.id);
        predavac2.ime = req.body.ime;
        predavac2.prezime = req.body.prezime;
        predavac2.radni_staz = req.body.radni_staz;
        predavac2.save();
        res.send(predavac2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;