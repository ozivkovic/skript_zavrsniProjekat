const express = require('express');
const { sequelize, Users } = require('../models');
const bcrypt = require('bcrypt');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));



function authToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.status(401).json({ msg: err });
  
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
        if (err) return res.status(403).json({ msg: err });
    
        req.user = user;
        
        next();
    });
}

route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/users/login', async (req, res) => {
    Users.findAll()
    .then( rows => res.json(rows) )
    .catch( err => res.status(500).json(err) );
   /* try{
    const user = await Users.findOne({where:{id:req.body.id}});
    return res.json(user);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }*/
});

route.post('/users', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            name: Joi.string().min(1).max(10).required(),
            password:Joi.string().min(1).max(10).required(),
            admin:Joi.number().min(0).max(1).required(),
            email:Joi.string().min(1).max(20).required(),
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        req.body.password = bcrypt.hashSync(req.body.password, 10);
        let userNovi = await Users.create(req.body);
        res.send(userNovi);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.get('/users/:id', async(req, res) => {
    try{
        const userDest=await Users.findOne({where:{id:req.params.id}});
        return res.json(userDest);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/users/:id', async(req, res) => {
    try{
        const userDest=await Users.findOne({where:{id:req.body.id}});
        userDest.destroy();
        res.send(userDest);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/users/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            name: Joi.string().min(1).max(10).required(),
            password:Joi.string().min(1).max(10).required(),
            admin:Joi.number().min(0).max(1).required(),
            email:Joi.string().min(1).max(20).required(),
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        req.body.password = bcrypt.hashSync(req.body.password, 10);
        const user2 = await Users.findByPk(req.params.id);
        user2.name = req.body.name;
        user2.password=req.body.password;
        user2.admin=req.body.admin;
        user2.email=req.body.email;
        user2.save();
        res.send(user2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;