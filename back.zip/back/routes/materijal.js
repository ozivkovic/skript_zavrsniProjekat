const express = require('express');
const { sequelize, Users,Materijal } = require('../models');
const Joi = require('joi');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/materijal', async (req, res) => {
    try{
    const sviMaterijali = await Materijal.findAll();
    return res.json(sviMaterijali);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/materijal', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required(),
            autor:Joi.string().min(1).max(100).required(),
            kursId:Joi.number().min(1).max(1000).required(),
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviMaterijal = await Materijal.create(req.body);
        res.send(noviMaterijal);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/materijal/:id', async(req, res) => {
    try{
    let materijal = await Materijal.findByPk(req.params.id);
    await materijal.destroy();
    res.send(materijal);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/materijal/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            naziv: Joi.string().min(1).max(10).required(),
            autor:Joi.string().min(1).max(100).required(),
            kursId:Joi.number().min(1).max(1000).required(),
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const materijal2= await Materijal.findByPk(req.params.id);
        materijal2.naziv = req.body.naziv;
        materijal2.autor=req.body.autor;
        materijal2.kursId=req.body.kursId;
        materijal2.save();
        res.send(materijal2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;