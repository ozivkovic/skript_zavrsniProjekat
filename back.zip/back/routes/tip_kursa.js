const express = require('express');
const { sequelize, Users,Tip_Kursa } = require('../models');
const jwt = require('jsonwebtoken');
const Joi = require('joi');

require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

// function authToken(req, res, next) {
//     const authHeader = req.headers['authorization'];
//     const token = authHeader && authHeader.split(' ')[1];
  
//     if (token == null) return res.status(401).json({ msg: err });
  
//     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
//         if (err) return res.status(403).json({ msg: err });
    
//         req.user = user;
        
//         next();
//     });
// }

// route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/tip_kursa', async (req, res) => {
    try{
    const sviTiooviKursa = await Tip_Kursa.findAll();
    return res.json(sviTiooviKursa);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/tip_kursa', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            tip: Joi.string().min(1).max(10).required(),
            opis:Joi.string().min(1).max(100).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        let noviTipKursa = await Tip_Kursa.create(req.body);
        res.send(noviTipKursa);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/tip_kursa/:id', async(req, res) => {
    try{
        
        const tip_kursa=await Tip_Kursa.findOne({where:{id:req.body.id}});
        tip_kursa.destroy();
        res.send(tip_kursa);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/tip_kursa/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            tip: Joi.string().min(1).max(10).required(),
            opis:Joi.string().min(1).max(100).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
        const tip_kursa2 = await Tip_Kursa.findByPk(req.params.id);
        tip_kursa2.tip = req.body.tip;
        tip_kursa2.opis = req.body.opis;
        
        tip_kursa2.save();
        res.send(tip_kursa2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;