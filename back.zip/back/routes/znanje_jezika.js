const express = require('express');
const { sequelize, Users,Znanje_Jezika } = require('../models');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

function authToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
  
    if (token == null) return res.status(401).json({ msg: err });
  
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
        if (err) return res.status(403).json({ msg: err });
    
        req.user = user;
        
        next();
    });
}

route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/znanje_jezika', async (req, res) => {
    try{
    const svaZnanjaJezika = await Znanje_Jezika.findAll();
    return res.json(svaZnanjaJezika);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/znanje_jezika', async (req, res) => {
    try{
        let novoZnanjeJezika = await Znanje_Jezika.create(req.body);
        res.send(novoZnanjeJezika);
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/znanje_jezika/:jezikId/details/:predavacId', async(req, res) => {
    try{
        const znanje=await Znanje_Jezika.findOne({
            where: {
                jezikId: req.body.jezikId,
                predavacId: req.body.predavacId
              }
        });
        znanje.destroy();
        res.send(znanje);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/znanje_jezika/:jezikId/details/:predavacId", async(req, res) => {
    try{

        const znanje2 = await await Znanje_Jezika.findOne({
            where: {
                jezikId: req.body.jezikId,
                predavacId: req.body.predavacId
              }
        });

        znanje2.jezikId = req.body.jezikIdNew;
        znanje2.predavacId = req.body.predavacIdNew;
        znanje2.save();
        res.send(znanje2);
    } catch(err){

    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;