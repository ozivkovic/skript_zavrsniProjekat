const express = require('express');
const Joi = require('joi');

const { sequelize, Users,Polaznik } = require('../models');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const route = express.Router();
route.use(express.json());
route.use(express.urlencoded({ extended: true }));

function authToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
  
    if (token == null) return res.status(401).json({ msg: err });
  
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
    
        if (err) return res.status(403).json({ msg: err });
    
        req.user = user;
        
        next();
    });
}

route.use(authToken);

route.get('/users', (req, res) => {
    Users.findAll()
        .then( rows => res.json(rows) )
        .catch( err => res.status(500).json(err) );
});

route.get('/polaznik', async (req, res) => {
    try{
    const sviPolaznici = await Polaznik.findAll();
    return res.json(sviPolaznici);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

route.post('/polaznik', async (req, res) => {
    try{
        const shema = Joi.object().keys({
            ime: Joi.string().min(1).max(10).required(),
            prezime:Joi.string().min(1).max(10).required(),
            godiste:Joi.number().min(4).max(3000).required()
            });
        
        const {error, succ} = shema.validate(req.body);
        if(error){
            console.log(error.details[0].message);
        }else{
            let noviPolaznik = await Polaznik.create(req.body);
            res.send(noviPolaznik);
        }
    } catch(err){
        console.log(err);
        res.status(500).json({ error: "Greska", data: err });
    }
});

route.delete('/polaznik/:id', async(req, res) => {
    try{
    //let polaznik = await Polaznik.findByPk(req.params.id);
    const polaznik=await Polaznik.findOne({where:{id:req.body.id}});
    polaznik.destroy();
    res.send(polaznik);
   // await polaznik.destroy();    
    
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});



route.put("/polaznik/:id", async(req, res) => {
    try{
        const shema = Joi.object().keys({
            ime: Joi.string().min(1).max(10).required(),
            prezime:Joi.string().min(1).max(10).required(),
            godiste:Joi.number().min(4).max(3000).required()
            });
    const {error, succ} = shema.validate(req.body);
    if(error){
        console.log(error.details[0].message);
        return;
    }
    const polaznik2 = await Polaznik.findByPk(req.params.id);
    polaznik2.ime = req.body.ime;
    polaznik2.prezime = req.body.prezime;
    polaznik2.godiste = req.body.godiste;
    polaznik2.save();
    res.send(polaznik2);
    } catch(err){
    console.log(err);
    res.status(500).json({ error: "Greska", data: err });
    }
});

module.exports = route;