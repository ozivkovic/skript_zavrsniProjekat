'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('grupas', 
      [
        {id:"901",oznaka:"101",kursId:"801",predavacId:"301"},
        {id:"902",oznaka:"102",kursId:"802",predavacId:"302"},
        {id:"903",oznaka:"103",kursId:"801",predavacId:"303"},
        {id:"904",oznaka:"104",kursId:"803",predavacId:"302"},
        {id:"905",oznaka:"105",kursId:"804",predavacId:"305"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Grupa', null, {});
  }
};