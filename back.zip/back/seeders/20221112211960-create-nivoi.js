'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('nivos', 
      [
        {id:"701",oznaka:"A1",opis:"niži osnovni CEF nivo"},
        {id:"702",oznaka:"A2",opis:"viši osnovni CEF nivo"},
        {id:"703",oznaka:"B1",opis:"niži srednji CEF nivo"},
        {id:"704",oznaka:"B2",opis:"viši srednji CEF nivo"},
        {id:"705",oznaka:"C1",opis:"niži napredni CEF nivo"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Nivo', null, {});
  }
};