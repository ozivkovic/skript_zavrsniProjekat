'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('predavacs', 
      [
        {id:"301",ime:"Petar",prezime:"Stanic",radni_staz:"15"},
        {id:"302",ime:"Mihailo",prezime:"Simic",radni_staz:"4"},
        {id:"303",ime:"Filip",prezime:"Aleksic",radni_staz:"2"},
        {id:"304",ime:"Aleksa",prezime:"Maksic",radni_staz:"7"},
        {id:"305",ime:"Milos",prezime:"Jevremovic",radni_staz:"21"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Predavac', null, {});
  }
};