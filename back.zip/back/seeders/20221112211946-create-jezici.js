'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('jeziks', 
      [
        {id:"401",naziv:"Engleski"},
        {id:"402",naziv:"Francuski"},
        {id:"403",naziv:"Nemacki"},
        {id:"404",naziv:"Spanski"},
        {id:"405",naziv:"Italijanski"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Jezik', null, {});
  }
};