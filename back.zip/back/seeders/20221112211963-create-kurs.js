'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('kurs', 
      [
        {id:"801",naziv:"Oxford kurs",tipKursaId:"501",jezikId:"403",nivoId:"701"},
        {id:"802",naziv:"Ingeducation kurs",tipKursaId:"502",jezikId:"402",nivoId:"704"},
        {id:"803",naziv:"Belano kurs",tipKursaId:"502",jezikId:"401",nivoId:"703"},
        {id:"804",naziv:"Liber kurs",tipKursaId:"503",jezikId:"403",nivoId:"705"},
        {id:"805",naziv:"Kontext kurs",tipKursaId:"504",jezikId:"405",nivoId:"704"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Kurs', null, {});
  }
};