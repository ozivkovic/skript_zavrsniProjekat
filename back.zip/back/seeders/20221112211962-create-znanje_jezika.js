'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('znanje_jezikas', 
      [
        {jezikId:"401",predavacId:"302"},
        {jezikId:"402",predavacId:"302"},
        {jezikId:"405",predavacId:"301"},
        {jezikId:"401",predavacId:"304"},
        {jezikId:"405",predavacId:"305"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Znanje_Jezika', null, {});
  }
};