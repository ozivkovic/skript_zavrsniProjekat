'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('tip_kursas', 
      [
        {id:"501",tip:"Opsti",opis:"Osnovni cilj opšteg kursa je da se uz pomoć najsavremenijih metoda, dinamične i interaktivne nastave, polaznici osposobe da koriste jezik u formalnim i neformalnim situacijama."},
        {id:"502",tip:"Ubrzani",opis:""},
        {id:"503",tip:"Specijalizovani",opis:" U pitanju su kursevi koji su primarno usmereni na konkretnu oblasti."},
        {id:"504",tip:"Poslovni",opis:""},
        {id:"505",tip:"Konverzacijski",opis:"Svako ko želi da poboljša komunikacijske veštine i usavrši ih, na raspolaganju ima konverzacijski kurs"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Tip_Kursa', null, {});
  }
};