'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
 
    await queryInterface.bulkInsert('pohadjanjes', 
      [
        {grupaId:"901",polaznikId:"201"},
        {grupaId:"902",polaznikId:"202"},
        {grupaId:"903",polaznikId:"201"},
        {grupaId:"901",polaznikId:"202"},
        {grupaId:"901",polaznikId:"204"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Pohadjanje', null, {});
  }
};