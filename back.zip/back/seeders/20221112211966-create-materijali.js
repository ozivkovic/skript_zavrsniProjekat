'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('materijals', 
      [
        {id:"601",naziv:"GoogleDrive",autor:"Mihajlo Maric",kursId:"801"},
        {id:"602",naziv:"Udzbenik",autor:"Zivko Peric",kursId:"802"},
        {id:"603",naziv:"Radna sveska",autor:"Marija Maljkovic",kursId:"802"},
        {id:"604",naziv:"CD",autor:"Milan Aleksic",kursId:"803"},
        {id:"605",naziv:"Recnik",autor:"Mihajlo Maric",kursId:"804"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Materijal', null, {});
  }
};