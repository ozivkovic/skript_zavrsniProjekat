'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('polazniks', 
      [
        {id:"201",ime:"Mihailo",prezime:"Lukic",godiste:"2003"},
        {id:"202",ime:"Aleksa",prezime:"Simic",godiste:"1997"},
        {id:"203",ime:"Luka",prezime:"Petrovic",godiste:"2000"},
        {id:"204",ime:"Marija",prezime:"Aleksic",godiste:"2002"},
        {id:"205",ime:"Ana",prezime:"Petrovic",godiste:"2001"},
        
      ], {});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('Polaznik', null, {});
  }
};