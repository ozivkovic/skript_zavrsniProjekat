const express = require('express');
const { sequelize } = require('./models');
const grps = require('./routes/grupa');
const typeOfCourses=require('./routes/tip_kursa');
const courses=require('./routes/kurs');
const jezik = require('./routes/jezik');
const nivo = require('./routes/nivo');
const materijal = require('./routes/materijal')
const predavac = require('./routes/predavac')
const msg = require('./routes/messages')


const app = express();


const cors=require('cors');

var corsOptions = {
    origin: '*',
    optionSuccessStatus: 200
}

app.use(cors(corsOptions));



app.use('/api', grps);
app.use('/api', typeOfCourses);
app.use('/api', courses);
app.use('/api', jezik);
app.use('/api', nivo);
app.use('/api', materijal);
app.use('/api', predavac);
app.use('/api', msg);



app.listen({ port: 8002 }, async () => {
    await sequelize.authenticate();
});
